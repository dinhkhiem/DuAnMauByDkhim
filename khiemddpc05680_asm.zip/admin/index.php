<?php 

header('Location: trang-chinh/');