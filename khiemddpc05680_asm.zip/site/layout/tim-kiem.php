<form class="pb-3" action="<?= $SITE_URL ?>/hang-hoa/liet-ke.php" method="POST">
    <div class="input-group">
        <input type="text" class="form-control" name="kyw" placeholder="Nhập từ khóa...">
        <div class="input-group-append">
            <button class="btn bg-info" type="submit" name="timkiem"><i class="fa fa-search text-white"></i></button>
        </div>
    </div>
</form>