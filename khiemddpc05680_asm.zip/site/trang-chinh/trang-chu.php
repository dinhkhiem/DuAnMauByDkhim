<!-- Slider -->
<section class="slider">
    <!-- ================== COMPONENT SLIDER  BOOTSTRAP  ==================  -->
    <?php require "../trang-chinh/slider.php"; ?>
    <!-- ==================  COMPONENT SLIDER BOOTSTRAP end.// ==================  .// -->
</section>


<!-- Special  -->
<section class="section-specials padding-y border-bottom mt-5">

    <?php require "../trang-chinh/special.php"; ?>

</section>

<!-- Sản phẩm đặc biệt-->
<section class="special-product">

    <?php require "../trang-chinh/dac-biet.php"; ?>

</section>