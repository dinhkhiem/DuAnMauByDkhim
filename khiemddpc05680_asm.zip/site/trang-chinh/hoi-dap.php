<section class="wthree-row pt-3 pb-sm-5 w3-contact">
        <div class="container py-sm-5 pb-5">
            <h3 class="head_agileinfo text-center text-capitalize pb-5 style" style="color:cadetblue"><marquee> Liên Hệ <i class="fas fa-address-card"></marquee></h3>
            <div class="row contact-form pt-lg-5">
                <div class="col-lg-6 wthree-form-left"> 
                    <!-- contact form grid -->
                    <div class="contact-top1">   
                    <h5 class="text-dark mb-4 text-capitalize">Liên Hệ Cho Tôi</h5>                     
                        <form action="#" method="get" class="f-color" id="lien_he">
                            <div class="form-group">
                                <label for="contactusername">Tên</label>
                                <input type="text" class="form-control" id="contactusername" name="ho_ten">
                            </div>
                            <div class="form-group">
                                <label for="contactemail">Email</label>
                                <input type="email" class="form-control" id="contactemail" name="email" >
                            </div>
                            <div class="form-group">
                                <label for="contactcomment">Nội dung</label>
                                <textarea class="form-control" rows="5" id="contactcomment" name="content"></textarea>
                            </div>
                            <button type="submit" class="btn btn-info btn-block" name="btn-lienhe">Submit</button>
                        </form>
                    </div>
                    <!--  //contact form grid ends here -->
                </div>
                <!-- contact details -->
                <div class="col-lg-6 contact-bottom pl-5 mt-lg-0  ">
                    <!-- contact details grid1-->
                    <div class="address">
                        <h5 class=" text-capitalize">Địa Chỉ</h5>
                        <address>
                            <p class="c-txt">Vinh Binh - Hoa Binh - Bac Lieu <br>
                            Can Tho - City</p>                            
                        </address>
                    </div>
                    <!-- contact details grid2-->
                    <div class="address  ">
                        <h5 class=" text-capitalize">Thông tin liên lạc</h5>
                        <p>
                            0946046053</p>                                               
                    </div>
                    <!-- contact details grid3 -->
                    <div class="address mt-md-0  ">
                        <h5 class=" text-capitalize">Email</h5>
                        <p>
                            <a href="mailto:info@example.com">khiemddpc05680@fpt.edu.vn</a><br>
                            <a href="mailto:info@example.com"> dinhkhiem2021.hb@gmail.com</a>
                        </p>  
                        <h5>
                            Google Map
                        </h5>
                        <div>      
                             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3256.8635524780584!2d105.75627078259085!3d9.98206785543884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31a08906415c355f%3A0x416815a99ebd841e!2zRlBUIFBPTFlURUNITklDIEPhuqZOIFRIxqA!5e0!3m2!1svi!2s!4v1689957071716!5m2!1svi!2s" width="300" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>                            
                        </div>                      
                    </div>
                    <!-- //contact details row ends here -->
                </div>
            </div>
            <!-- //contact details container -->
        </div>
        <!-- contact map grid -->
        
        <!--//contact map grid ends here-->
    </section>